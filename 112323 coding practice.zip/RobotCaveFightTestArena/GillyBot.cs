﻿using System.Drawing;

namespace RobotCaveFightTestArena
{
    internal class Plankton : IRobot
    {

        //initiate private variables and lists and such
        private Plankton myPlankton = new Plankton();
        private string Name;
        private string Color;
        private string ColorTwo;
        private string Students;
        List<string> StudentNames;
        double Health;
        List<double> stats = new List<double>();
        double attack;
        double speed;
        double defense;
        double constitution;


        public double GetHealth()
        {
            throw new NotImplementedException();
        }

        public double GetMaxHealth(double constitution)
        {
            //set health to constitution times 10
            this.Health = 10 * constitution;
            double health = this.Health;
            return health;
        }

        public Color GetPrimaryColor()
        {
            //add primary color to robot
            Color Color = ColorTranslator.FromHtml("ff1234"); // color red
            Convert.ToString(Color);
            return Color;
        }

        public string GetRobotName()
        {
            //add nmae to robot "plankton"
            string name = "Plankton";
            this.Name = name;
            return name;
        }

        public string GetSecondaryColor()
        {
            //set 2nd color
            Color ColorTwo = ColorTranslator.FromHtml("000000"); // color black
            Convert.ToString(ColorTwo);
            return this.ColorTwo;
        }

        public double GetSpeed()
        {
            throw new NotImplementedException();
        }

        public (List<double>, double, double, double, double) GetStats()
        {

            //set stats to 10 just for baseline idea
            this.attack = 10.0;
            this.speed = 10.0;
            this.defense = 10.0;
            this.constitution = 10.0;

            double attack = this.attack;
            double speed = this.speed;
            double defense = this.defense;
            double constitution = this.constitution;

            //add stats to list
            stats.Add(attack);
            stats.Add(speed);
            stats.Add(defense);
            stats.Add(constitution);

            return (stats, attack, speed, defense, constitution);
        }

        public string[] GetStudentNames()
        {
            //create list and add student names to list
            string[] GetStudentNames() => new string[] { "Mason", "Eli", "Tyler", "Robert" };
            return GetStudentNames();
        }


        public ActionResult PerformAction(IRobot opponent)
        {
            throw new NotImplementedException();
        }

        public void Reset()
        {
            GetStats();
            GetMaxHealth(constitution);
        }

        public void TakeDamage(double health, double defense)
        {
            double damageDealt;
            double incomingDamage = 0;
            double newHealth;
            damageDealt = incomingDamage - (defense / 100 * incomingDamage);
            newHealth = health - damageDealt;
        }
    }
}
